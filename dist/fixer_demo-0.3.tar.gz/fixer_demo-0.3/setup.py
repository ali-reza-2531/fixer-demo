from setuptools import setup

setup(name='fixer-demo', version=0.3, description='Fixer service demo package',
      url='https://github.com/ali-reza-2531/fixer-demo', author='Alireza', author_email='alirezashams09@gamil.com',
      license='MIT', install_requires=['requests'], packages=['fixer'], zip_safe=False)
